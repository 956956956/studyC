#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>

typedef struct food {
	char foodName[20];
	int calories;
}food;

void PrintInfo(food* foods, int nFood, int calories) {
	int a = 0, b = 0;
	printf("%dĮ�θ� �̻� : ", calories);
	for (int i = 0; i < 5; i++) {
		if (foods[i].calories >= calories) {
			printf("%s ", foods[i].foodName);
		}
	}
	printf("\n%dĮ�θ� �̸� : ", calories);

	for (int j = 0; j < 5; j++) {
		if (foods[j].calories < calories) {
			printf("%s ", foods[j].foodName);
		}
	}
	
	
}



int main() {
	struct food Food[5];
	strcpy(Food[0].foodName, "�ܹ���");
	Food[0].calories = 900;
	strcpy( Food[1].foodName, "�ʹ�");
	Food[1].calories = 700;
	strcpy(Food[2].foodName, "���");
	Food[2].calories = 500;
	strcpy( Food[3].foodName, "�Ұ���");
	Food[3].calories = 600;
	strcpy(Food[4].foodName, "���");
	Food[4].calories = 200;
	int n;
	printf("Į�θ� ���� �Է��ϼ��� : ");
	scanf("%d", &n);
	PrintInfo(Food, 5, n);
	

}