#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int beebeebeebeebeam=0;

int garosero(int a[5][5]) {
	for (int i = 0; i < 5; i++) {
		int count_garo = 0;
		int count_sero = 0;
		for (int j = 0; j < 5; j++) {
			if (a[i][j] == a[i][0]) count_garo++;
			if (a[j][i] == a[0][j]) count_sero++;
		}
		if (count_garo == 5) beebeebeebeebeam ++;
		if (count_sero == 5) beebeebeebeebeam ++;
	}

	return beebeebeebeebeam;
}




int main() {
	int bingo[5][5];
	printf("������ �迭 �Է� : \n");
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			scanf("%d", &bingo[i][j]);
		}
	}
	int a =garosero(bingo);
	
	printf("Total %d bingo", a);
	
}