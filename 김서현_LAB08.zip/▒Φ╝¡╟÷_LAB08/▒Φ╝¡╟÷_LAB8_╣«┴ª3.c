#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {
	int a[5][6]={0}, temp=0;
	printf("������ �迭 �Է� : \n");
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			scanf("%d", &a[i][j]);
			a[i][5] += a[i][j];
		}
	}
	

	for (int i = 0; i < 5; i++) {
		int k, j;
		for (k = 0; k < 5; k++) {
			for (j = 0; j < 4; j++) {
				if (a[i][j] > a[i][j + 1]) {
					temp = a[i][j];
					a[i][j] = a[i][j + 1];
					a[i][j + 1] = temp;
				}
			}
			j = 0;
		}
		k = 0;
	}
	
	for (int i = 0; i < 5; i++) {
		for (int j = i+1; j < 5; j++) {
			if (a[i][5] > a[j][5])
			{
				for (int k = 0; k < 6; k++) {
					temp = a[i][k];
					a[i][k] = a[j][k];
					a[j][k] = temp;
				}
			}
		}
		
	}


	//���⼭�������

	printf("\n");



	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
		

	return 0;
}